package com.src.java.crm.utilities;

public enum DefectTypeConstant {
	DEFECT, ENHANCEMENT, SUGGESTION
}
