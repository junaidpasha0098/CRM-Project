package com.src.java.crm.exceptions;

public class ServiceException extends RuntimeException{
	public ServiceException(String message) {
		super(message);
	}
}
