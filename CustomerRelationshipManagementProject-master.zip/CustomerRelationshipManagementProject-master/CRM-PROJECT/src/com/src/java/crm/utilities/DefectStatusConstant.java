package com.src.java.crm.utilities;

public enum DefectStatusConstant {
	SUBMITTED, IN_PROGRESS, CLOSED
}
